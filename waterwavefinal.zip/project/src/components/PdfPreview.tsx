import React, { useEffect, useState, useCallback } from 'react';
import { applyWatermark } from '../utils/pdfUtils';
import type { WatermarkOptions } from '../utils/types';

interface PdfPreviewProps extends WatermarkOptions {
  pdfData: string;
}

export default function PdfPreview({
  pdfData,
  watermarkText,
  logoImage,
  color = '#000000',
  opacity,
  position
}: PdfPreviewProps) {
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const generatePreview = useCallback(async () => {
    let objectUrl: string | null = null;
    
    try {
      setIsLoading(true);
      setError(null);

      const watermarkedPdfBytes = await applyWatermark(pdfData, {
        text: watermarkText,
        logoImage,
        color,
        opacity,
        position
      });

      const blob = new Blob([watermarkedPdfBytes], { type: 'application/pdf' });
      objectUrl = URL.createObjectURL(blob);
      setPreviewUrl(objectUrl);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to generate PDF preview';
      setError(message);
      console.error('Preview generation error:', error);
    } finally {
      setIsLoading(false);
    }

    return objectUrl;
  }, [pdfData, watermarkText, logoImage, color, opacity, position]);

  useEffect(() => {
    let objectUrl: string | null = null;

    if (pdfData) {
      generatePreview().then(url => {
        objectUrl = url;
      });
    }

    return () => {
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [pdfData, generatePreview]);

  if (isLoading) {
    return (
      <div className="w-full h-[600px] flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full h-[600px] flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="text-red-500 text-center">
          <p className="font-semibold mb-2">Error Preview</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-[600px] rounded-lg overflow-hidden">
      {previewUrl && (
        <iframe
          src={previewUrl}
          className="w-full h-full border-0"
          title="PDF Preview"
        />
      )}
    </div>
  );
}